class StreamStat {

    constructor(concurrentViewers, scheduledStartTime, actualStartTime, activeLiveChatId) {
        this.concurrentViewers = concurrentViewers
        this.scheduledStartTime = scheduledStartTime
        this.actualStartTime = actualStartTime
        this.activeLiveChatId = activeLiveChatId
    }
}