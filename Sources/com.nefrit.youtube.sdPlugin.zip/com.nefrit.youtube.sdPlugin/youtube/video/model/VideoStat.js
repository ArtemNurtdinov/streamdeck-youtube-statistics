class VideoStat {

    constructor(viewCount, likeCount, favoriteCount, commentCount) {
        this.viewCount = viewCount
        this.likeCount = likeCount
        this.favoriteCount = favoriteCount
        this.commentCount = commentCount
    }
}