class ChannelStat {

    constructor(viewCount, subscribersCount, hiddenSubscribersCount, videoCount) {
        this.viewCount = viewCount
        this.subscribersCount = subscribersCount
        this.hiddenSubscribersCount = hiddenSubscribersCount
        this.videoCount = videoCount
    }
}